public interface placeable
{
    int getTotal();
    int getLocation();
    int getType(); //set when initialized

    void inputTotal(int total);
    void inputLocation(int location);


}
