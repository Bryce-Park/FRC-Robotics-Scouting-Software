import java.lang.reflect.Array;
import java.util.ArrayList;

public class Main
{
    public static void main(String[] args) throws Throwable
    {
        String inputSheet = "C:/Users/jpark/IdeaProjects/Scouting Software/FRC 2019 Scouting Form (roughdraft).xlsx";
        String pitCommentInputSheet = "C:/Users/jpark/IdeaProjects/Scouting Software/FRC 2019 Pit Scouting (Responses) (1).xlsx";
        processor processorTester = new processor();
        processorTester.generateSheets(inputSheet,pitCommentInputSheet);
    }
}

