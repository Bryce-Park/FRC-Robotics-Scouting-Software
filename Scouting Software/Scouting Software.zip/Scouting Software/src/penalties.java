public class penalties
{

}
